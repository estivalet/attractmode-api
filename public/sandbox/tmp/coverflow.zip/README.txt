A Pen created at CodePen.io. You can find this one at https://codepen.io/hjortureh/pen/pGlki.

 CoverFlow built with CSS3 and a small doze of JavaScript