# JS Cover Flow
A Cover Flow component made for the web. More info: https://wesleyluyten.com/projects/js-cover-flow

[![JS Cover Flow](https://raw.github.com/luwes/js-cover-flow/master/preview.png)](http://luwes.co/labs/js-cover-flow/)

## Contributors
Paul Albrecht (http://www.siteway.de/)

## Important
Licensed under [Creative Commons Attribution-NonCommercial-ShareAlike 3.0](http://creativecommons.org/licenses/by-nc-sa/3.0/)